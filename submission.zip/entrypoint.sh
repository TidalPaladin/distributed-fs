#!/bin/sh
set -e
exec java -jar /app/hw3.jar $MODE
