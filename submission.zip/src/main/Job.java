abstract class Job {}
